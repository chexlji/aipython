number_list= [x for x in range(1,11) if x % 2 == 0]
print(number_list)

citys = ["Seoul", "New York", "London", "Shanghai", "Paris", "Tokyo"]
s_city = [city for city in citys if city.startswith('S')]
print(s_city) 

nums=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
odd_nums=list(filter(lambda x : x % 2 == 0, nums))
print(odd_nums)