txt = "apple#banana#cherry#orange"
x = txt.split("#")
print(x)

words = {'Python', 'Java', 'Ruby'}
y = "->".join(words)
print(y) 

number_list = [x**2 for x in range(10) if x % 2 == 0]
print(number_list)
